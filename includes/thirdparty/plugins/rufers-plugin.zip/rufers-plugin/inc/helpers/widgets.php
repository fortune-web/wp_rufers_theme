<?php
///----Blog widgets---
//Popular Post 
class Rufers_Popular_Post extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Popular_Post', /* Name */esc_html__('Rufers Popular Post','rufers'), array( 'description' => esc_html__('Show the Popular Post', 'rufers' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!--Popular Posts-->
        <?php echo wp_kses_post($before_title.$title.$after_title); ?>
        <div class="sidebar-blog-post">
            <ul class="blog-post">
                <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					 
					$this->posts($query_string);
				?>
            </ul>
        </div>
                
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Popular Post', 'rufers');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'rufers'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'rufers'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <li>
                <div class="inner">
                    <div class="img-box" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);">
                        <div class="overlay-content">
                            <a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><i class="fa fa-link" aria-hidden="true"></i></a>
                        </div>
                    </div>
                    <div class="title-box">
                        <div class="date"><?php echo get_the_date();?></div>
                        <h4><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h4>
                    </div>
                </div>
            </li>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Our Project
class Rufers_Our_Projects extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Our_Projects', /* Name */esc_html__('Rufers Our Projects','rufers'), array( 'description' => esc_html__('Show the Our Projects', 'rufers' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <?php echo wp_kses_post($before_title.$title.$after_title); ?>
        <div class="instagram-feed-box">
            <ul class="instagram-items">
                <?php 
					$args = array('post_type' => 'rufers_project', 'showposts'=>$instance['number']);
					if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'project_cat','field' => 'id','terms' => (array)$instance['cat']));
					 
					$this->posts($args);
				?>
            </ul>
        </div>
                
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Our Projects';
		$number = ( $instance ) ? esc_attr($instance['number']) : 6;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Our Projects', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'rufers'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'rufers'), 'selected'=>$cat, 'taxonomy' => 'project_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
				global $post; 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <li>
                <div class="inner">
                    <div class="img-box" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);">
                        <div class="overlay-content">
                            <a class="lightbox-image" data-fancybox="gallery"
                                href="<?php echo esc_url($post_thumbnail_url);?>">
                                <span class="flaticon-zoom"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </li>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

//Subscribe Form
class Rufers_Subscribe_Form extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Subscribe_Form', /* Name */esc_html__('Rufers Subscribe Form','rufers'), array( 'description' => esc_html__('Show the Subscribe Form', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
        <!-- Newsletter Widget -->
        <div class="last-box">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="sidebar-subscribe-content-box">
                <div class="inner-content">
                    <p><?php echo wp_kses_post($instance['content']); ?></p>
                    <div class="sidebar-subscribe-form">
                        <?php echo do_shortcode($instance['mailchimp_form_url']); ?>
                    </div>
                </div>
            </div>
        </div>
                        
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['content'] = $new_instance['content'];
		$instance['mailchimp_form_url'] = $new_instance['mailchimp_form_url'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Newsletter';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$mailchimp_form_url = ($instance) ? esc_attr($instance['mailchimp_form_url']) : '';
				
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('Title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" ><?php echo wp_kses_post($title); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('mailchimp_form_url')); ?>"><?php esc_html_e('Mailchimp Form Url:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('mailchimp_form_url')); ?>" name="<?php echo esc_attr($this->get_field_name('mailchimp_form_url')); ?>" ><?php echo wp_kses_post($mailchimp_form_url); ?></textarea>
        </p>   
                
		<?php 
	}
	
}


///----footer widgets---
//About Company
class Rufers_About_Company extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_About_Company', /* Name */esc_html__('Rufers About Company','rufers'), array( 'description' => esc_html__('Show the About Company', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
        <!--Footer Column-->
        <div class="marbtm50">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="our-company-info">
                <div class="text-box">
                    <p><?php echo wp_kses_post($instance['content']); ?></p>
                </div>
                <ul>
                    <li>
                        <h6><?php echo wp_kses_post($instance['subtitle']); ?></h6>
                        <p><?php echo wp_kses_post($instance['opening_hours']); ?></p>
                    </li>
                </ul>
                <?php if($instance['widget_btn_title']){ ?>
                <div class="btn-box">
                    <a class="btn-one" href="<?php echo esc_url($instance['widget_btn_link']); ?>">
                        <span class="txt"><?php echo wp_kses_post($instance['widget_btn_title']); ?></span>
                    </a>
                </div>
				<?php } ?>
            </div>
        </div>
        <!--End single footer widget-->
                    
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['content'] = $new_instance['content'];
		$instance['subtitle'] = $new_instance['subtitle'];
		$instance['opening_hours'] = $new_instance['opening_hours'];
		$instance['widget_btn_title'] = $new_instance['widget_btn_title'];
		$instance['widget_btn_link'] = $new_instance['widget_btn_link'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'About Services';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$subtitle = ($instance) ? esc_attr($instance['subtitle']) : '';
		$opening_hours = ($instance) ? esc_attr($instance['opening_hours']) : '';
		$widget_btn_title = ($instance) ? esc_attr($instance['widget_btn_title']) : '';
		$widget_btn_link = ($instance) ? esc_attr($instance['widget_btn_link']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('About Services', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle')); ?>"><?php esc_html_e('Enter Sub Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('We are Available', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('subtitle')); ?>" name="<?php echo esc_attr($this->get_field_name('subtitle')); ?>" type="text" value="<?php echo esc_attr($subtitle); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('opening_hours')); ?>"><?php esc_html_e('Enter Opening Hours:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Mon-Sat: 09.00 am to 6.30 pm', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('opening_hours')); ?>" name="<?php echo esc_attr($this->get_field_name('opening_hours')); ?>" type="text" value="<?php echo esc_attr($opening_hours); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>"><?php esc_html_e('Enter Button Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('More Details', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_title')); ?>" type="text" value="<?php echo esc_attr($widget_btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>"><?php esc_html_e('Enter Button Link:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_link')); ?>" type="text" value="<?php echo esc_attr($widget_btn_link); ?>" />
        </p>    
                
		<?php 
	}
	
}

//Contact Details
class Rufers_Contact_Details extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Contact_Details', /* Name */esc_html__('Rufers Contact Details','rufers'), array( 'description' => esc_html__('Show the Contact Details', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="contact-widget">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="footer-widget-contact-info">
                    <ul>
                        <?php if($instance['subtitle'] || $instance['w_phone_no'] || $instance['w_email']){ ?>
                        <li>
                            <?php if($instance['subtitle']){ ?><h6><?php echo wp_kses_post($instance['subtitle']); ?></h6><?php } ?>
                            <?php if($instance['w_phone_no']){ ?><p><?php esc_html_e('Phone:', 'rufers'); ?> <a href="tel:<?php echo esc_attr($instance['w_phone_no']); ?>"><?php echo wp_kses_post($instance['w_phone_no']); ?></a></p><?php } ?>
                            <?php if($instance['w_email']){ ?><p><?php esc_html_e('Email:', 'rufers'); ?> <a href="mailto:<?php echo esc_attr($instance['w_email']); ?>"><?php echo wp_kses_post($instance['w_email']); ?></a></p><?php } ?>
                        </li>
                        <?php } ?>
                        <?php if($instance['subtitle2'] || $instance['w_address']){ ?>
                        <li>
                            <?php if($instance['subtitle2']){ ?><h6><?php echo wp_kses_post($instance['subtitle2']); ?></h6><?php } ?>
                            <?php if($instance['w_address']){ ?><p><?php echo wp_kses_post($instance['w_address']); ?></p><?php } ?>
                        </li>
                        <?php } ?>
                    </ul>
                    
                    <?php if( $instance['show'] ): ?>
                    <div class="footer-social-link">
                    	<?php echo wp_kses_post(rufers_get_social_icons_two()); ?>
                    </div>
					<?php endif; ?>
                    
                </div>
            </div>
           
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['subtitle'] = $new_instance['subtitle'];
		$instance['w_phone_no'] = $new_instance['w_phone_no'];
		$instance['w_email'] = $new_instance['w_email'];
		$instance['subtitle2'] = $new_instance['subtitle2'];
		$instance['w_address'] = $new_instance['w_address'];
		$instance['show'] = $new_instance['show'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Contact Details';
		$subtitle = ($instance) ? esc_attr($instance['subtitle']) : '';
		$w_phone_no = ($instance) ? esc_attr($instance['w_phone_no']) : '';
		$w_email = ($instance) ? esc_attr($instance['w_email']) : '';
		$subtitle2 = ($instance) ? esc_attr($instance['subtitle2']) : '';
		$w_address = ($instance) ? esc_attr($instance['w_address']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Contact Details', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle')); ?>"><?php esc_html_e('Enter Sub Heading:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('General Quries', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('subtitle')); ?>" name="<?php echo esc_attr($this->get_field_name('subtitle')); ?>" type="text" value="<?php echo esc_attr($subtitle); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_phone_no')); ?>"><?php esc_html_e('Phone Number:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('+1-800-555-44-00', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('w_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('w_phone_no')); ?>" type="text" value="<?php echo esc_attr($w_phone_no); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_email')); ?>"><?php esc_html_e('Email Addess:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('info@example.com', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('w_email')); ?>" name="<?php echo esc_attr($this->get_field_name('w_email')); ?>" type="text" value="<?php echo esc_attr($w_email); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle2')); ?>"><?php esc_html_e('Enter Sub Heading:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Office Location', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('subtitle2')); ?>" name="<?php echo esc_attr($this->get_field_name('subtitle2')); ?>" type="text" value="<?php echo esc_attr($subtitle2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_address')); ?>"><?php esc_html_e('Address:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('w_address')); ?>" name="<?php echo esc_attr($this->get_field_name('w_address')); ?>" ><?php echo wp_kses_post($w_address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'rufers'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
               
		<?php 
	}
	
}

//Latest Post 
class Rufers_Latest_Post extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Latest_Post', /* Name */esc_html__('Rufers Latest Post','rufers'), array( 'description' => esc_html__('Show the Latest Post', 'rufers' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Trending Posts -->
        <div class="pdtop50">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <ul class="widget-posts-box">
                <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					 
					$this->posts($query_string);
				?>
            </ul>
			<?php if($instance['widget_btn_title']){ ?>
            <div class="widget-more-post-button">
                <a class="btn-two" href="<?php echo esc_url($instance['widget_btn_link']); ?>"> <?php echo wp_kses_post($instance['widget_btn_title']); ?></a>
            </div>
            <?php } ?>
		</div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		$instance['widget_btn_title'] = $new_instance['widget_btn_title'];
		$instance['widget_btn_link'] = $new_instance['widget_btn_link'];
				
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Latest Post', 'rufers');
		$number = ( $instance ) ? esc_attr($instance['number']) : 2;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';
        $widget_btn_title = ( $instance ) ? esc_attr($instance['widget_btn_title']) : '';
        $widget_btn_link = ( $instance ) ? esc_attr($instance['widget_btn_link']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'rufers'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'rufers'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>"><?php esc_html_e('Enter Button Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Read More', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_title')); ?>" type="text" value="<?php echo esc_attr($widget_btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>"><?php esc_html_e('Enter Button Link:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_link')); ?>" type="text" value="<?php echo esc_attr($widget_btn_link); ?>" />
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <li>
                <div class="inner">
                    <div class="img-box" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);">
                        <div class="overlay-content">
                            <a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><i class="fa fa-link" aria-hidden="true"></i></a>
                        </div>
                    </div>
                    <div class="title-box">
                        <p><?php echo wp_kses_post(get_the_date());?></p>
                        <h4><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php echo wp_trim_words( get_the_title(), 6, '...' );?></a></h4>
                    </div>
                </div>
            </li>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}


///----footer Two widgets---
//About Company Two
class Rufers_About_Company_Two extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_About_Company_Two', /* Name */esc_html__('Rufers About Company Two','rufers'), array( 'description' => esc_html__('Show the About Company Two', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="single-footer-widget-style2 marbtm50">
                <div class="our-company-info">
                    <div class="footer-logo">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url($instance['widget_logo_img2']); ?>" alt="<?php esc_attr_e('Awesome Image', 'rufers');?>"></a>
                    </div>
                    <div class="text-box">
                        <p><?php echo wp_kses_post($instance['content']); ?></p>
                    </div>
                    <?php if($instance['phone_title'] || $instance['widget_phone_no']){ ?>
                    <div class="emergency-contact">
                        <h6><?php echo wp_kses_post($instance['phone_title']); ?></h6>
                        <?php if($instance['widget_phone_no']){ ?>
                        <h3>
                            <span class="flaticon-headphone"></span>
                            <a href="tel:<?php echo esc_attr($instance['widget_phone_no']); ?>"><?php echo wp_kses_post($instance['widget_phone_no']); ?></a>
                        </h3>
                        <?php } ?>
                    </div>
					<?php } ?>
         		</div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['widget_logo_img2'] = strip_tags($new_instance['widget_logo_img2']);
		$instance['content'] = $new_instance['content'];
		$instance['phone_title'] = $new_instance['phone_title'];
		$instance['widget_phone_no'] = $new_instance['widget_phone_no'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img2 = ($instance) ? esc_attr($instance['widget_logo_img2']) : 'http://fastwpdemo.com/newwp/rufers/wp-content/uploads/2021/12/footer-logo.png';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$phone_title = ($instance) ? esc_attr($instance['phone_title']) : '';
		$widget_phone_no = ($instance) ? esc_attr($instance['widget_phone_no']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img2')); ?>"><?php esc_html_e('Logo Image Url:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Image Url', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img2')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img2')); ?>" type="text" value="<?php echo esc_attr($widget_logo_img2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_title')); ?>"><?php esc_html_e('Phone Title:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_title')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_title')); ?>" ><?php echo wp_kses_post($phone_title); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_phone_no')); ?>"><?php esc_html_e('Phone Number:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('+1800-12-3456', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_phone_no')); ?>" type="text" value="<?php echo esc_attr($widget_phone_no); ?>" />
        </p>
               
                
		<?php 
	}
	
}

//Subscribe Form Two
class Rufers_Subscribe_Form_Two extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Subscribe_Form_Two', /* Name */esc_html__('Rufers Subscribe Form Two','rufers'), array( 'description' => esc_html__('Show the Subscribe Form Two', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
        <!--Footer Column-->
        <div class="pdtop50">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="footer-subscribe-box">
                <div class="text">
                    <p><?php echo wp_kses_post($instance['content']); ?></p>
                </div>
                <div class="subscribe-form" >
                    <?php echo do_shortcode($instance['form_id']); ?>
                </div>
            </div>
        </div>
            
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['content'] = $new_instance['content'];
		$instance['form_id'] = $new_instance['form_id'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Newsletter';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$form_id = ($instance) ? esc_attr($instance['form_id']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Newsletter', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('form_id')); ?>"><?php esc_html_e('MailChimp Form Url:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('form_id')); ?>" name="<?php echo esc_attr($this->get_field_name('form_id')); ?>" ><?php echo wp_kses_post($form_id); ?></textarea>
        </p>
               
                
		<?php 
	}
	
}


///----footer Three widgets---
//About Company Three
class Rufers_About_Company_Three extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_About_Company_Three', /* Name */esc_html__('Rufers About Company Three','rufers'), array( 'description' => esc_html__('Show the About Company Three', 'rufers' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <div class="marbtm50">
            <div class="our-company-info">
                <div class="footer-logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url($instance['widget_logo_img']); ?>" alt="<?php esc_attr_e('Awesome Image', 'rufers');?>"></a>
                </div>
                <div class="text-box">
                    <p><?php echo wp_kses_post($instance['content']); ?></p>
                    <?php if($instance['widget_btn_title']){ ?>
                    <div class="btn-box2">
                        <a class="btn-two" href="<?php echo esc_url($instance['widget_btn_link']); ?>"> <?php echo wp_kses_post($instance['widget_btn_title']); ?></a>
                    </div>
                    <?php } ?>
                </div>
            </div>

            <div class="footer-widget-gallery">
                <ul>
                  <?php 
						$args = array('post_type' => 'rufers_project', 'showposts'=>$instance['number']);
						if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'project_cat','field' => 'id','terms' => (array)$instance['cat']));
						 
						$this->posts($args);
					?>
                </ul>
            </div>

        </div>
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['widget_logo_img'] = strip_tags($new_instance['widget_logo_img']);
		$instance['content'] = $new_instance['content'];
		$instance['widget_btn_title'] = $new_instance['widget_btn_title'];
		$instance['widget_btn_link'] = $new_instance['widget_btn_link'];
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img = ($instance) ? esc_attr($instance['widget_logo_img']) : 'http://fastwpdemo.com/newwp/rufers/wp-content/uploads/2021/12/footer-logo-2.png';
		$content = ( $instance ) ? esc_attr($instance['content']) : '';
		$widget_btn_title = ( $instance ) ? esc_attr($instance['widget_btn_title']) : '';
		$widget_btn_link = ( $instance ) ? esc_attr($instance['widget_btn_link']) : '' ;
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>"><?php esc_html_e('Logo Image Url:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Logo Image Url', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img')); ?>" type="text" value="<?php echo esc_attr($widget_logo_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>"><?php esc_html_e('Enter Button Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('More Details', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_title')); ?>" type="text" value="<?php echo esc_attr($widget_btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>"><?php esc_html_e('Enter Button Link:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_btn_link')); ?>" type="text" value="<?php echo esc_attr($widget_btn_link); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'rufers'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'rufers'), 'selected'=>$cat, 'taxonomy' => 'project_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
				global $post; 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <li>
                <div class="img-box" style="background-image:url('<?php echo esc_url($post_thumbnail_url);?>')">
                    <div class="overlay-content">
                        <a class="lightbox-image" data-fancybox="gallery" href="<?php echo esc_url($post_thumbnail_url);?>">
                            <i class="flaticon-zoom"></i>
                        </a>
                    </div>
                </div>
            </li>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

//Get In Touch
class Rufers_Get_In_Touch extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Get_In_Touch', /* Name */esc_html__('Rufers Get In Touch','rufers'), array( 'description' => esc_html__('Show the Get In Touch', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="pdtop50">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="footer-widget-contact-info footer-widget-contact-info--style2">
                    <ul>
                        <?php if($instance['w_phone_no'] || $instance['w_email']){ ?>
                        <li>
                            <div class="inner-icon">
                                <span class="flaticon-phone-call-3"></span>
                            </div>
                            <div class="inner-text">
                                <?php if($instance['subtitle']){ ?><h6><?php echo wp_kses_post($instance['subtitle']); ?></h6><?php } ?>
								<?php if($instance['w_phone_no']){ ?><p><?php esc_html_e('Phone:', 'rufers'); ?> <a href="tel:<?php echo esc_attr($instance['w_phone_no']); ?>"><?php echo wp_kses_post($instance['w_phone_no']); ?></a></p><?php } ?>
                                <?php if($instance['w_email']){ ?><p><?php esc_html_e('Email:', 'rufers'); ?> <a href="mailto:<?php echo esc_attr($instance['w_email']); ?>"><?php echo wp_kses_post($instance['w_email']); ?></a></p><?php } ?>
                            </div>
                        </li>
                        <?php } ?>
                        <?php if($instance['subtitle2'] || $instance['w_address']){ ?>
                        <li>
                            <div class="inner-icon">
                                <span class="flaticon-placeholder-2"></span>
                            </div>
                            <div class="inner-text">
                                <?php if($instance['subtitle2']){ ?><h6><?php echo wp_kses_post($instance['subtitle2']); ?></h6><?php } ?>
                            	<?php if($instance['w_address']){ ?><p><?php echo wp_kses_post($instance['w_address']); ?></p><?php } ?>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>
                    <?php if( $instance['show'] ): ?>
                    <div class="footer-social-link style2">
                       	<?php echo wp_kses_post(rufers_get_social_icons_two()); ?>
                    </div>
					<?php endif; ?>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['subtitle'] = $new_instance['subtitle'];
		$instance['w_phone_no'] = $new_instance['w_phone_no'];
		$instance['w_email'] = $new_instance['w_email'];
		$instance['subtitle2'] = $new_instance['subtitle2'];
		$instance['w_address'] = $new_instance['w_address'];
		$instance['show'] = $new_instance['show'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Get In Touch';
		$subtitle = ($instance) ? esc_attr($instance['subtitle']) : '';
		$w_phone_no = ($instance) ? esc_attr($instance['w_phone_no']) : '';
		$w_email = ($instance) ? esc_attr($instance['w_email']) : '';
		$subtitle2 = ($instance) ? esc_attr($instance['subtitle2']) : '';
		$w_address = ($instance) ? esc_attr($instance['w_address']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Get In Touch', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle')); ?>"><?php esc_html_e('Enter Sub Heading:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('General Quries', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('subtitle')); ?>" name="<?php echo esc_attr($this->get_field_name('subtitle')); ?>" type="text" value="<?php echo esc_attr($subtitle); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_phone_no')); ?>"><?php esc_html_e('Phone Number:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('+1-800-555-44-00', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('w_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('w_phone_no')); ?>" type="text" value="<?php echo esc_attr($w_phone_no); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_email')); ?>"><?php esc_html_e('Email Addess:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('info@example.com', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('w_email')); ?>" name="<?php echo esc_attr($this->get_field_name('w_email')); ?>" type="text" value="<?php echo esc_attr($w_email); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle2')); ?>"><?php esc_html_e('Enter Sub Heading:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Office Location', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('subtitle2')); ?>" name="<?php echo esc_attr($this->get_field_name('subtitle2')); ?>" type="text" value="<?php echo esc_attr($subtitle2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('w_address')); ?>"><?php esc_html_e('Address:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('w_address')); ?>" name="<?php echo esc_attr($this->get_field_name('w_address')); ?>" ><?php echo wp_kses_post($w_address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'rufers'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
               
		<?php 
	}
	
}


///----Service Sidebar widgets---
//Our Brochures
class Rufers_Brochures extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Brochures', /* Name */esc_html__('Rufers Our Brochures','rufers'), array( 'description' => esc_html__('Show the info Our Brochures', 'rufers' )) );
	}
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      	
        <div class="info-ownload-box">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <ul>
                <?php if($instance['pdf_file_title1']){ ?>
                <li>
                    <div class="icon">
                        <span class="flaticon-pdf"></span>
                    </div>
                    <div class="inner">
                        <div class="title">
                            <h4><?php echo wp_kses_post($instance['pdf_file_title1']); ?></h4>
                            <h6><?php echo wp_kses_post($instance['pdf_file_size1']); ?></h6>
                        </div>
                        <div class="download-btn">
                            <a href="<?php echo esc_url($instance['pdf_file_link1']); ?>"><i class="fa fa-cloud-download" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </li>
                <?php } ?>
                <?php if($instance['pdf_file_title2']){ ?>
                <li>
                    <div class="icon">
                        <span class="flaticon-pdf"></span>
                    </div>
                    <div class="inner">
                        <div class="title">
                            <h4><?php echo wp_kses_post($instance['pdf_file_title2']); ?></h4>
                            <h6><?php echo wp_kses_post($instance['pdf_file_size2']); ?></h6>
                        </div>
                        <div class="download-btn">
                            <a href="<?php echo esc_url($instance['pdf_file_link2']); ?>"><i class="fa fa-cloud-download" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </li>
                <?php } ?>
            </ul>
        </div>
                    
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		$instance['pdf_file_title1'] = $new_instance['pdf_file_title1'];
		$instance['pdf_file_size1'] = $new_instance['pdf_file_size1'];
		$instance['pdf_file_link1'] = $new_instance['pdf_file_link1'];
		$instance['pdf_file_title2'] = $new_instance['pdf_file_title2'];
		$instance['pdf_file_size2'] = $new_instance['pdf_file_size2'];
		$instance['pdf_file_link2'] = $new_instance['pdf_file_link2'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$pdf_file_title1 = ($instance) ? esc_attr($instance['pdf_file_title1']) : '';
		$pdf_file_size1 = ($instance) ? esc_attr($instance['pdf_file_size1']) : '';
		$pdf_file_link1 = ($instance) ? esc_attr($instance['pdf_file_link1']) : '';
		$pdf_file_title2 = ($instance) ? esc_attr($instance['pdf_file_title2']) : '';
		$pdf_file_size2 = ($instance) ? esc_attr($instance['pdf_file_size2']) : '';
		$pdf_file_link2 = ($instance) ? esc_attr($instance['pdf_file_link2']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Our Brochures', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_title1')); ?>"><?php esc_html_e('PDF Title V1:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Service Details', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_title1')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_title1')); ?>" type="text" value="<?php echo esc_attr($pdf_file_title1); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_size1')); ?>"><?php esc_html_e('File Size V1:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('[450KB]', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_size1')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_size1')); ?>" type="text" value="<?php echo esc_attr($pdf_file_size1); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_link1')); ?>"><?php esc_html_e('PDF Link V1:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_link1')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_link1')); ?>" type="text" value="<?php echo esc_attr($pdf_file_link1); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_title2')); ?>"><?php esc_html_e('PDF Title V2:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Product Models', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_title2')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_title2')); ?>" type="text" value="<?php echo esc_attr($pdf_file_title2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_size2')); ?>"><?php esc_html_e('File Size V2:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('[860KB]', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_size2')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_size2')); ?>" type="text" value="<?php echo esc_attr($pdf_file_size2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_link2')); ?>"><?php esc_html_e('PDF Link V2:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_link2')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_link2')); ?>" type="text" value="<?php echo esc_attr($pdf_file_link2); ?>" />
        </p>
               
		<?php 
	}
	
}

//Need Help
class Rufers_Need_Help extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Need_Help', /* Name */esc_html__('Rufers Need Help','rufers'), array( 'description' => esc_html__('Show the Need Help', 'rufers' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
		<div class="sidebar-contact-info-box">
            <div class="img-box">
                <div class="inner">
                    <img src="<?php echo esc_url($instance['bg_img']); ?>" alt="<?php esc_attr_e('Awesome Image', 'rufers'); ?>">
                </div>
                <div class="overlay-title">
                    <div class="border-left-box"></div>
                    <h3><?php echo wp_kses_post($instance['title']); ?></h3>
                </div>
                <div class="round-box">
                    <h6><?php echo wp_kses_post($instance['quality_info']); ?></h6>
                </div>
            </div>
            <div class="text-box">
                <div class="sec-title center text-center">
                    <div class="sub-title">
                        <h6>
                            <span class="border-left"></span>
                            <?php echo wp_kses_post($instance['wiget_sub_title']); ?>
                            <span class="border-right"></span>
                        </h6>
                    </div>
                </div>
                <h3><a href="tel:<?php echo esc_attr($instance['phone_no3']); ?>"><?php echo wp_kses_post($instance['phone_no3']); ?></a></h3>
                <p><?php echo wp_kses_post($instance['content']); ?></p>
                <div class="btn-box">
                    <a class="btn-one" href="<?php echo esc_url($instance['btn_link_v3']); ?>">
                        <span class="txt"><?php echo wp_kses_post($instance['btn_title_v3']); ?></span>
                    </a>
                </div>
            </div>
        </div>
                    
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['bg_img'] = strip_tags($new_instance['bg_img']);
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['quality_info'] = strip_tags($new_instance['quality_info']);
		$instance['wiget_sub_title'] = $new_instance['wiget_sub_title'];
		$instance['phone_no3'] = $new_instance['phone_no3'];
		$instance['content'] = $new_instance['content'];
		$instance['btn_title_v3'] = $new_instance['btn_title_v3'];
		$instance['btn_link_v3'] = $new_instance['btn_link_v3'];
		
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		
		$bg_img = ($instance) ? esc_attr($instance['bg_img']) : 'http://fastwpdemo.com/newwp/rufers/wp-content/uploads/2021/12/sidebar-contact-info.jpg';
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$quality_info = ($instance) ? esc_attr($instance['quality_info']) : '';
		$wiget_sub_title = ($instance) ? esc_attr($instance['wiget_sub_title']) : '';
		$phone_no3 = ($instance) ? esc_attr($instance['phone_no3']) : '';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$btn_title_v3 = ($instance) ? esc_attr($instance['btn_title_v3']) : '';
		$btn_link_v3 = ($instance) ? esc_attr($instance['btn_link_v3']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('bg_img')); ?>"><?php esc_html_e('background Image Url:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('background Image Url', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('bg_img')); ?>" name="<?php echo esc_attr($this->get_field_name('bg_img')); ?>" type="text" value="<?php echo esc_attr($bg_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" ><?php echo wp_kses_post($title); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('quality_info')); ?>"><?php esc_html_e('Quality Info Description:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('quality_info')); ?>" name="<?php echo esc_attr($this->get_field_name('quality_info')); ?>" ><?php echo wp_kses_post($quality_info); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('wiget_sub_title')); ?>"><?php esc_html_e('Sub Heading:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Make an Appointment', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('wiget_sub_title')); ?>" name="<?php echo esc_attr($this->get_field_name('wiget_sub_title')); ?>" type="text" value="<?php echo esc_attr($wiget_sub_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_no3')); ?>"><?php esc_html_e('Phone Number:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('+1-800-555-44-678', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_no3')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_no3')); ?>" type="text" value="<?php echo esc_attr($phone_no3); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Enter Description:', 'rufers'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_title_v3')); ?>"><?php esc_html_e('Button Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Get Call Back', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_title_v3')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_title_v3')); ?>" type="text" value="<?php echo esc_attr($btn_title_v3); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_link_v3')); ?>"><?php esc_html_e('Button Link:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_link_v3')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_link_v3')); ?>" type="text" value="<?php echo esc_attr($btn_link_v3); ?>" />
        </p>
               
                
		<?php 
	}
	
}

///Shop Sidebar
//Popular Products
class Rufers_Popular_Products extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Rufers_Popular_Products', /* Name */esc_html__('Rufers Popular Products','rufers'), array( 'description' => esc_html__('Show the Popular Products', 'rufers' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!--Start Single Sidebar Box-->
        <div class="single-sidebar-box last-box">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="sidebar-product-items">
                <ul class="product-items">
					<?php 
						$args = array('post_type' => 'product', 'showposts'=>$instance['number']);
						if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'product_cat','field' => 'id','terms' => (array)$instance['cat']));
						 
						$this->posts($args);
					?>
                </ul>
            </div>
        </div>
        <!--End Single Sidebar Box-->
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Popular Products';
		$number = ( $instance ) ? esc_attr($instance['number']) : 4;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'rufers'); ?></label>
            <input placeholder="<?php esc_attr_e('Popular Products', 'rufers');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'rufers'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'rufers'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'rufers'), 'selected'=>$cat, 'taxonomy' => 'product_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				global $post;
				while( $query->have_posts() ): $query->the_post();  
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <!--Start Single Shop Item style3-->
            <li>
                <div class="inner">
                    <div class="img-box" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);">
                        <div class="overlay-content">
                            <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
                                <i class="fa fa-link" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>
                    <div class="title-box">
                        <h4><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title();?></a></h4>
                        <div class="review-box">
                            <?php woocommerce_template_loop_rating(); ?>
                        </div>
                        <div class="value"><?php woocommerce_template_loop_price(); ?></div>
                    </div>
                </div>
            </li>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

