<?php

namespace RUFERSPLUGIN\Inc;


use RUFERSPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		$labels = array(
			'name'              => _x( 'Project Category', 'wprufers' ),
			'singular_name'     => _x( 'Project Category', 'wprufers' ),
			'search_items'      => __( 'Search Category', 'wprufers' ),
			'all_items'         => __( 'All Categories', 'wprufers' ),
			'parent_item'       => __( 'Parent Category', 'wprufers' ),
			'parent_item_colon' => __( 'Parent Category:', 'wprufers' ),
			'edit_item'         => __( 'Edit Category', 'wprufers' ),
			'update_item'       => __( 'Update Category', 'wprufers' ),
			'add_new_item'      => __( 'Add New Category', 'wprufers' ),
			'new_item_name'     => __( 'New Category Name', 'wprufers' ),
			'menu_name'         => __( 'Project Category', 'wprufers' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);

		register_taxonomy( 'project_cat', 'rufers_project', $args );
		
		//Services Taxonomy Start
		$labels = array(
			'name'              => _x( 'Service Category', 'wprufers' ),
			'singular_name'     => _x( 'Service Category', 'wprufers' ),
			'search_items'      => __( 'Search Category', 'wprufers' ),
			'all_items'         => __( 'All Categories', 'wprufers' ),
			'parent_item'       => __( 'Parent Category', 'wprufers' ),
			'parent_item_colon' => __( 'Parent Category:', 'wprufers' ),
			'edit_item'         => __( 'Edit Category', 'wprufers' ),
			'update_item'       => __( 'Update Category', 'wprufers' ),
			'add_new_item'      => __( 'Add New Category', 'wprufers' ),
			'new_item_name'     => __( 'New Category Name', 'wprufers' ),
			'menu_name'         => __( 'Service Category', 'wprufers' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);


		register_taxonomy( 'service_cat', 'rufers_service', $args );
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wprufers' ),
			'singular_name'     => _x( 'Testimonials Category', 'wprufers' ),
			'search_items'      => __( 'Search Category', 'wprufers' ),
			'all_items'         => __( 'All Categories', 'wprufers' ),
			'parent_item'       => __( 'Parent Category', 'wprufers' ),
			'parent_item_colon' => __( 'Parent Category:', 'wprufers' ),
			'edit_item'         => __( 'Edit Category', 'wprufers' ),
			'update_item'       => __( 'Update Category', 'wprufers' ),
			'add_new_item'      => __( 'Add New Category', 'wprufers' ),
			'new_item_name'     => __( 'New Category Name', 'wprufers' ),
			'menu_name'         => __( 'Testimonials Category', 'wprufers' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'rufers_testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wprufers' ),
			'singular_name'     => _x( 'Team Category', 'wprufers' ),
			'search_items'      => __( 'Search Category', 'wprufers' ),
			'all_items'         => __( 'All Categories', 'wprufers' ),
			'parent_item'       => __( 'Parent Category', 'wprufers' ),
			'parent_item_colon' => __( 'Parent Category:', 'wprufers' ),
			'edit_item'         => __( 'Edit Category', 'wprufers' ),
			'update_item'       => __( 'Update Category', 'wprufers' ),
			'add_new_item'      => __( 'Add New Category', 'wprufers' ),
			'new_item_name'     => __( 'New Category Name', 'wprufers' ),
			'menu_name'         => __( 'Team Category', 'wprufers' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'rufers_team', $args );
		
		//Faqs Taxonomy Start
		$labels = array(
			'name'              => _x( 'Faqs Category', 'wprufers' ),
			'singular_name'     => _x( 'Faq Category', 'wprufers' ),
			'search_items'      => __( 'Search Category', 'wprufers' ),
			'all_items'         => __( 'All Categories', 'wprufers' ),
			'parent_item'       => __( 'Parent Category', 'wprufers' ),
			'parent_item_colon' => __( 'Parent Category:', 'wprufers' ),
			'edit_item'         => __( 'Edit Category', 'wprufers' ),
			'update_item'       => __( 'Update Category', 'wprufers' ),
			'add_new_item'      => __( 'Add New Category', 'wprufers' ),
			'new_item_name'     => __( 'New Category Name', 'wprufers' ),
			'menu_name'         => __( 'Faq Category', 'wprufers' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'faqs_cat' ),
		);


		register_taxonomy( 'faqs_cat', 'rufers_faqs', $args );
	}
	
}
