<?php
return array(
	'title'      => 'Rufers Service Setting',
	'id'         => 'rufers_meta_service',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'rufers_service' ),
	'sections'   => array(
		array(
			'id'     => 'rufers_service_meta_setting',
			'fields' => array(
				array(
					'id'       => 'service_icon',
					'type'     => 'select',
					'title'    => esc_html__( 'Service Icons', 'rufers' ),
					'options'  => get_fontawesome_icons(),
				),
				array(
					'id'    => 'ext_url',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Link Here', 'rufers' ),
				),
				array(
					'id'    => 'servic_no',
					'type'  => 'text',
					'title' => esc_html__( 'Service No.', 'rufers' ),
				),
			),
		),
	),
);