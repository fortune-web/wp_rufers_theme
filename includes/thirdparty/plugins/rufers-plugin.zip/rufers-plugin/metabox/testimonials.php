<?php
return array(
	'title'      => 'Rufers Testimonials Setting',
	'id'         => 'rufers_meta_testimonials',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'rufers_testimonials' ),
	'sections'   => array(
		array(
			'id'     => 'rufers_testimonials_meta_setting',
			'fields' => array(
				array(
					'id'    => 'client_name',
					'type'  => 'text',
					'title' => esc_html__( 'Author Name', 'rufers' ),
				),
				array(
					'id'    => 'test_designation',
					'type'  => 'text',
					'title' => esc_html__( 'Author Designation', 'rufers' ),
				),
				array(
					'id'    => 'testimonial_rating',
					'type'  => 'select',
					'title' => esc_html__( 'Choose the Client Rating', 'rufers' ),
					'options'  => array(
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
					),
				),
			),
		),
	),
);