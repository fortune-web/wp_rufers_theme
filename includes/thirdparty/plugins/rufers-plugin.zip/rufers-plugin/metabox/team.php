<?php
return array(
	'title'      => 'Rufers Team Setting',
	'id'         => 'rufers_meta_team',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'rufers_team' ),
	'sections'   => array(
		array(
			'id'     => 'rufers_team_meta_setting',
			'fields' => array(
				array(
					'id'    => 'designation',
					'type'  => 'text',
					'title' => esc_html__( 'Designation', 'rufers' ),
				),
				array(
					'id'    => 'team_url',
					'type'  => 'text',
					'title' => esc_html__( 'Website Link', 'rufers' ),
				),
				array(
					'id'    => 'social_profile',
					'type'  => 'social_media',
					'title' => esc_html__( 'Social Profiles', 'rufers' ),
				),
				
			),
		),
	),
);