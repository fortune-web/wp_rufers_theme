<?php
return array(
	'title'      => 'Rufers Project Setting',
	'id'         => 'rufers_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'rufers_project' ),
	'sections'   => array(
		array(
			'id'     => 'rufers_projects_meta_setting',
			'fields' => array(
				array(
					'id'    => 'project_link',
					'type'  => 'text',
					'title' => esc_html__( 'Read More Link', 'rufers' ),
				),
				array(
					'id'    => 'dimension',
					'type'  => 'select',
					'title' => esc_html__( 'Choose the Extra height', 'rufers' ),
					'options'  => array(
						'extra_width' => esc_html__( 'Extra Width', 'rufers' ),
						'normal_width' => esc_html__( 'Normal Width', 'rufers' ),
					),
					'default'  => 'normal_height',
				),
			),
		),
	),
);