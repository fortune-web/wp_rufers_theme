<?php
return array(
	'title'      => 'Rufers Setting',
	'id'         => 'rufers_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page', 'post', 'rufers_team', 'product', 'rufers_service'  ),
	'sections'   => array(
		require_once RUFERSPLUGIN_PLUGIN_PATH . '/metabox/header.php',
		require_once RUFERSPLUGIN_PLUGIN_PATH . '/metabox/banner.php',
		require_once RUFERSPLUGIN_PLUGIN_PATH . '/metabox/sidebar.php',
		require_once RUFERSPLUGIN_PLUGIN_PATH . '/metabox/footer.php',
	),
);