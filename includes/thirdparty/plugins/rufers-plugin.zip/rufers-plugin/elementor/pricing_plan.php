<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Pricing_Plan extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_pricing_plan';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Pricing Plan', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'pricing_plan',
			[
				'label' => esc_html__( 'Pricing Plan', 'rufers' ),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your SubTitle', 'rufers' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);
		$this->add_control(
             'table', 
			  	[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
				[
					['plan_title' => esc_html__('Basic', 'rufers')],
					['plan_title' => esc_html__('Standard', 'rufers')],
					['plan_title' => esc_html__('Premium', 'rufers')],						
					['plan_title' => esc_html__('Advanced', 'rufers')]					
				],
				'fields' => 
				[
					[
						'name' => 'plan_title',
						'label' => esc_html__('Plan Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'plan_price',
						'label' => esc_html__('Plan Price', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'plan_duration',
						'label' => esc_html__('Plan Duration', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'features_list',
						'label' => esc_html__('Feature List', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
                    ],
					[
						'name' => 'btn_title',
						'label' => esc_html__('Button Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
                    ],
					[
						'name' => 'btn_link',						
						'label' => __( 'Button Url', 'rufers' ),						
						'type' => Controls_Manager::URL,						
						'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),						
						'show_external' => true,						
						'default' => ['url' => '','is_external' => true,'nofollow' => true,],
					],	
					[
						'name' => 'style_two',
						'label'   => esc_html__( 'Choose Different Style', 'rufers' ),
						'label_block' => true,
						'type'    => Controls_Manager::SELECT,
						'default' => 'one',
						'options' => array(
							'one' => esc_html__( 'Choose Table Style One', 'rufers' ),
							'two' => esc_html__( 'Choose Table Style Two', 'rufers' ),
							'three' => esc_html__( 'Choose Table Style Three', 'rufers' ),
						),
					],
				],
				'title_field' => '{{plan_title}}',
            ]
        );
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
    
    <!--Start pricing plan area-->
    <section class="pricing-plan-area">
        <div class="container">
            <?php if($settings['subtitle'] || $settings['title']){ ?>
            <div class="sec-title center text-center">
                <?php if($settings['subtitle']){ ?>
                <div class="sub-title">
                    <h6><span class="border-left"></span> <?php echo wp_kses($settings['subtitle'], true) ;?> <span class="border-right"></span></h6>
                </div>
                <?php } ?>
                <?php if($settings['title']){ ?><h2><?php echo wp_kses($settings['title'], true) ;?></h2><?php } ?>
            </div>
            <?php } ?>
            <div class="row">
				<?php foreach($settings['table'] as $key => $item):?>
                <!--Start single price box-->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="single-price-box <?php if($item['style_two'] == 'three') echo 'style3'; if($item['style_two'] == 'two') echo 'style2'; else echo ''; ?>">
                        <?php if($item['plan_title']){ ?>
                        <div class="table-header text-center">
                            <div class="dot-left zoominout"></div>
                            <div class="dot-right zoominout-2"></div>
                            <h3><?php echo wp_kses($item['plan_title'], true) ;?></h3>
                        </div>
                        <?php } ?>
                        <div class="table-content">
                            
							<?php if($item['style_two'] == 'three'): ?>
                            <div class="package text-center">
                                <h2><?php echo wp_kses($item['plan_price'], true) ;?></h2>
                                <span><?php echo wp_kses($item['plan_duration'], true) ;?></span>
                            </div>
                            <?php elseif($item['style_two'] == 'two'): ?>
                            <div class="package text-center">
                                <h2><?php echo wp_kses($item['plan_price'], true) ;?></h2>
                                <span><?php echo wp_kses($item['plan_duration'], true) ;?></span>
                            </div>
                            <?php else: ?>
                            <div class="package text-center">
                                <div class="package-bg" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/pricing-table-bg.png);"></div>
                                <h2><?php echo wp_kses($item['plan_price'], true) ;?></h2>
                                <span><?php echo wp_kses($item['plan_duration'], true) ;?></span>
                            </div>
                            <?php endif ;?>
                            
							<?php $features_list = $item['features_list'];
							   if(!empty($features_list)){
							   $features_list = explode("\n", ($features_list)); 
							?>
							<div class="price-list">
                                <ul>
								<?php foreach($features_list as $features): ?>
                                   <?php echo wp_kses($features, true); ?>
                                <?php endforeach; ?>
								</ul>
							</div>
							<?php } ?>
                            
                            <?php if($item['btn_link'] || $item['btn_title']){ ?>
                            <div class="table-footer text-center">
                                <a class="btn-one" href="<?php echo esc_url($item['btn_link']['url']) ;?>">
                                    <span class="txt"><?php echo wp_kses($item['btn_title'], true) ;?></span>
                                </a>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <!--End single price box-->
                <?php endforeach;?>
            </div>
        </div>
    </section>
    <!--End pricing plan area-->
            
	<?php  
	}
}