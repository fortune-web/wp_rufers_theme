<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Our_Statement extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_our_statement';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Our Statement', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'our_statement',
			[
				'label' => esc_html__( 'Our Statement', 'rufers' ),
			]
		);		
		$this->add_control(
			'image_1',
			[
			  'label' => __( 'Background Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );		
		$this->add_control(
			'image_2',
			[
			  'label' => __( 'video Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );		
		$this->add_control(
			'video_url',
				[
				  'label' => __( 'Video Url', 'rufers' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],				
			 ]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'rufers' ),
			]
		);		
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);			
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'rufers' ),
			]
		);		
		$this->add_control(
        	'statement', 
			  	[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Mission Statement', 'rufers')],						
					],
				'fields' => 
				[
					[
						'name' => 'block_icons',
						'label' => esc_html__('Enter The icons', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::SELECT2,
                    	'options'  => get_fontawesome_icons(),
					],
					[
						'name' => 'block_title',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
                    ],
					[
						'name' => 'text',
						'label' => esc_html__('Text', 'rufers'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'features_list',
						'label' => esc_html__('Feature List', 'rufers'),
						'type' => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__('Enter your Feature List', 'rufers')
					],
				],
				'title_field' => '{{block_title}}',
            ]
        );
		
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
        
    <!--Start Statements Area-->     
    <section class="statements-area">
    	<?php if($settings['image_1']['id']){ ?><div class="statements-area-bg" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image_1']['id']));?>);"></div><?php } ?>
        <div class="container">        
            <div class="row">            
                <div class="col-xl-5">                
                    <div class="video-holder-box-style2" <?php if($settings['image_2']['id']){ ?>style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image_2']['id']));?>);"<?php } ?>>                        
                        <?php if($settings['video_url']['url']){ ?>
                        <div class="icon wow zoomIn animated" data-wow-delay="300ms" data-wow-duration="1500ms">                        
                            <a class="video-popup" title="Video Gallery" href="<?php echo esc_url($settings['video_url']['url']);?>">                                
                                <span class="flaticon-play-button"></span>                                
                            </a>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-xl-7">                
                    <div class="statements__content-box">                    
                    	<?php if( $settings['subtitle'] || $settings['title']){ ?>                    
                        <div class="sec-title">                        
                            <div class="sub-title">                            
                                <h6><span class="border-left"></span><?php echo wp_kses($settings['subtitle'], true); ?></h6>                                
                            </div>                            
                            <h2><?php echo wp_kses($settings['title'], true); ?></h2>                            
                        </div>                        
                        <?php } ?>
                        
                        <div class="inner-content">                        
                            <?php if($settings['text']){ ?>
                            <div class="top-text">                            
                                <p><?php echo wp_kses($settings['text'], true); ?></p>                                
                            </div> 
                            <?php } ?>                           
                            <div class="statements-main-content">                            
                                <div class="statements-carousel owl-carousel owl-theme owl-nav-style-one">                                
                                    <!--Start Single Box-->                                    
                                    <?php foreach($settings['statement'] as $key => $item):?>                                    
                                    <div class="single-box">                                    
                                        <div class="icon-box">                                        
                                            <span class="<?php echo esc_attr(str_replace( "icon ",  "", $item['block_icons']));?>"></span>                                            
                                        </div>                                        
                                        <div class="text-box">                                        
                                            <h3><?php echo wp_kses($item['block_title'], true) ;?></h3>                                            
                                            <p><?php echo wp_kses($item['text'], true) ;?></p>                                            
                                            <?php $features_list = $item['features_list'];    
                                                if(!empty($features_list)){            
                                                $features_list = explode("\n", ($features_list));    
                                            ?>                                        
                                            <ul>                                            
                                            	<?php foreach($features_list as $features): ?>                                            
                                                <li><span class="flaticon-arrow-pointing-left"></span><?php echo wp_kses($features, true); ?></li>
                                            	<?php endforeach; ?>                                           
                                        	</ul>                                        
                                        <?php } ?>
                                        </div>
                                     </div>                                    
                                     <?php endforeach;?>                                      
                                    <!--End Single Box-->
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </section>
    <!--End Statements Area-->
        
    <?php 
	}
}
