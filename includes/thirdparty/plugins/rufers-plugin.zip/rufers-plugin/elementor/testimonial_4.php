<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Testimonial_4 extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_testimonial_4';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Testimonial 4', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'testimonial_4',
			[							
				'label' => esc_html__( 'Testimonial 4', 'rufers' ),
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'rufers' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'rufers' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'rufers' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'rufers' ),
					'title'      => esc_html__( 'Title', 'rufers' ),
					'menu_order' => esc_html__( 'Menu Order', 'rufers' ),
					'rand'       => esc_html__( 'Random', 'rufers' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'rufers' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'rufers' ),
					'ASC'  => esc_html__( 'ASC', 'rufers' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'rufers'),
			  'label_block' => true,
			  'options' => get_testimonials_categories()
			]
		);
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		
        $paged = rufers_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-rufers' );
		$args = array(
			'post_type'      => 'rufers_testimonials',
			'posts_per_page' => rufers_set( $settings, 'query_number' ),
			'orderby'        => rufers_set( $settings, 'query_orderby' ),
			'order'          => rufers_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		
		if( rufers_set( $settings, 'query_category' ) ) $args['testimonial_cat'] = rufers_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );
		if ( $query->have_posts() ) 
	{ ?>
       
    <!--Start Testimonials Style1 area -->
    <section class="testimonials-style1-area testimonials-page-one">
        <div class="container">
            <div class="row">
               <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <!--Start Single Testimonials Style1-->
                <div class="col-xl-6 col-lg-12">
                    <div class="single-testimonials-style1">
                        <div class="img-holder">
                            <div class="top-pattern-bg"
                                style="background-image: url(<?php echo esc_url(get_template_directory_uri());?>/assets/images/pattern/thm-pattern-4.png);">
                            </div>
                            <div class="bottom-pattern-bg"
                                style="background-image: url(<?php echo esc_url(get_template_directory_uri());?>/assets/images/pattern/thm-pattern-5.png);">
                            </div>
                            <div class="img-box">
                                <?php the_post_thumbnail('rufers_150x150'); ?>
                            </div>
                            <div class="review-box">
                                <ul>
                                    <?php
                                        $ratting = get_post_meta( get_the_id(), 'testimonial_rating', true ); 
                                        for ($x = 1; $x <= 5; $x++) {
                                        if($x <= $ratting) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>'; 
                                        }
                                    ?>
                                </ul>
                            </div>
                        </div>
                        <div class="text-holder">
                            <div class="top">
                                <div class="icon">
                                    <span class="flaticon-quote-3"></span>
                                </div>
                                <div class="name">
                                    <h3><?php the_title(); ?></h3>
                                    <span><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></span>
                                </div>
                            </div>
                            <div class="text">
                                <p><?php echo wp_kses(rufers_trim(get_the_content(), $settings['text_limit']), true); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Single Testimonials Style1-->
               <?php endwhile; ?>
            </div>
        </div>
    </section>
    <!--End Testimonials Style1 area -->
   
	<?php }
    wp_reset_postdata();
	}
}