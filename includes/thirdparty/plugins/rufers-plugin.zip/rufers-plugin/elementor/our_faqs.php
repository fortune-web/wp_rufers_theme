<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Our_Faqs extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_our_faqs';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Our Faqs ', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'our_faqs',
			[
				'label' => esc_html__( 'Our Faqs ', 'rufers' ),
			]
		);
		$this->add_control(
			'image_1',
			[
			  'label' => __( 'Background Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$this->add_control(
          'form_subtitle',
			[
				'label'       => __( 'Form SubTitle', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Forms subtitle', 'rufers' ),
			]
		);			
		$this->add_control(
          'form_title',
			[
				'label'       => __( 'Form Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Forms title', 'rufers' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text ', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'rufers' ),
			]
		);
		$this->add_control(		
           'faqs_contact_form_url',		   
		   [
			'label'       => __( 'Free Estimation Form Url', 'rufers' ),				
			'type'        => Controls_Manager::TEXTAREA,				
			'dynamic'     => [				
					'active' => true,				
				],
		  		'placeholder' => __( '', 'rufers' )
			]
		);
		$this->add_control(
          'subtitle',
			[
				'label'       => __( 'SubTitle', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your subtitle', 'rufers' ),
			]
		);
		$this->add_control(
          'title',
			[
				'label'       => __( 'Faqs Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'rufers' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'rufers' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'rufers' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'rufers' ),
					'title'      => esc_html__( 'Title', 'rufers' ),
					'menu_order' => esc_html__( 'Menu Order', 'rufers' ),
					'rand'       => esc_html__( 'Random', 'rufers' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'rufers' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'rufers' ),
					'ASC'  => esc_html__( 'ASC', 'rufers' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'rufers'),
			  'label_block' => true,
			  'options' => get_faqs_categories()
			]
		);
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		
        $paged = rufers_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-rufers' );
		$args = array(
			'post_type'      => 'rufers_faqs',
			'posts_per_page' => rufers_set( $settings, 'query_number' ),
			'orderby'        => rufers_set( $settings, 'query_orderby' ),
			'order'          => rufers_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		
		if( rufers_set( $settings, 'query_category' ) ) $args['faqs_cat'] = rufers_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );
		if ( $query->have_posts() ) 
	{ ?>
 
    <!--Start Faq Style1 Area-->
    <section class="faq-style1-area">    
        <?php if($settings['image_1']['id']){ ?>
        <div class="faq-style1-bg" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image_1']['id']));?>);"></div>        
        <?php } ?>
        <div class="container">        
            <div class="row">
            	<div class="col-xl-6 col-lg-5">                
                    <div class="faq-form-box">                    
                        <div class="pattern-bg" style="background-image: url(<?php echo esc_url( get_template_directory_uri().'/assets/images/pattern/thm-pattern-7.png');?>);"></div>
                        <?php if( $settings['form_title'] || $settings['form_subtitle'] || $settings['text']){ ?>                            
                        <div class="sec-title">                        
                            <?php if($settings['form_subtitle']){ ?>
                            <div class="sub-title">                            
                                <h6><span class="border-left"></span><?php echo wp_kses($settings['form_subtitle'], true) ;?></h6>
                            </div>
                            <?php } ?>
                            <?php if( $settings['form_title']){ ?><h2><?php echo wp_kses($settings['form_title'], true) ;?></h2><?php } ?>
                            <?php if($settings['text']){ ?><p><?php echo wp_kses($settings['text'], true) ;?></p><?php } ?>
                        </div>                        
                        <?php } ?>
                        <?php if($settings['faqs_contact_form_url']){ ?>
                        <div class="default-form1">
                            <?php echo do_shortcode($settings['faqs_contact_form_url']) ;?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-7 text-right-rtl">                
                    <div class="faq-style1-content">                    
                    	<?php if( $settings['title'] || $settings['subtitle']){ ?>                    
                        <div class="sec-title">                        
                            <?php if($settings['subtitle']){ ?>
                            <div class="sub-title">                            
                                <h6><span class="border-left"></span><?php echo wp_kses($settings['subtitle'], true) ;?></h6>
                            </div>
                            <?php } ?>
                            <?php if( $settings['title']){ ?><h2><?php echo wp_kses($settings['title'], true) ;?></h2><?php } ?>
                        </div>
                        <?php } ?>
                         
                        <ul class="accordion-box">                        
                        	<?php $count = 1; while ( $query->have_posts() ) : $query->the_post(); ?>                        
                            <li class="accordion block <?php if($count == 1) echo 'active-block'?>">                            
                                <div class="acc-btn <?php if($count == 1) echo 'active'?>">                                
                                    <div class="icon-outer"><i class="flaticon-down-arrow-2"></i></div>                                    
                                    <h3><?php the_title();?></h3>                                    
                                </div>                                
                                <div class="acc-content <?php if($count == 1) echo 'current'?>">                                
                                    <p><?php echo wp_kses(rufers_trim(get_the_content(), $settings['text_limit']), true); ?></p>
                                </div>
                            </li>                            
                            <?php $count++; endwhile; ?> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Faq Style1 Area-->
	
	<?php }
    wp_reset_postdata();
	
	}
}