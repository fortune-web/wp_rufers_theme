<?php

namespace RUFERSPLUGIN\Element;


class Elementor {
	static $widgets = array(
		//Home Page
		'banner_1',
		'our_services',
		'about_company',
		'features',
		'work_gallery',
		'video_section',
		'work_process',
		'our_team',
		'testimonial',
		'testimonial_call_back',
		'our_blog',
		
		//Home Two Page
		'banner_2',
		'about_company_2',
		'funfact',
		'our_services_2',
		'why_choose_us',
		'our_gallery_2',
		'testimonial_2',
		'logo_box',
		'pricing_plan',
		'get_a_call',
		'our_blog_2',

		//Home Three Page
		'banner_3',
		'highlights',
		'our_services_3',
		'about_company_3',
		'funfacts_v2',
		'our_gallery_3',
		'why_choose_us_2',
		'our_faqs',
		'testimonial_3',
		'our_blog_3',
		'awards',
		
		//Home One Page
		'contact_us',
		
		//Inner Pages
		'our_statement',
		'our_history',
		'why_choose_us_3',
		'our_team_2',
		'project_v1',
		'project_v2',
		'project_v3',
		'project_v4',
		'our_faq_2',
		'comming_soon', 
		'testimonial_4',
		'our_services_4',
		'service_detail',
		'blog_grid_view',
		'blog_list_view',
		'contact_info',
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = RUFERSPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\RUFERSPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'rufers',
			[
				'title' => esc_html__( 'Rufers', 'rufers' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'rufers' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();