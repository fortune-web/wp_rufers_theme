<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Company_3 extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_about_company_3';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'About Company 3', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'about_company_3',
			[
				'label' => esc_html__( 'About Company 3', 'rufers' ),
			]
		);		
		$this->add_control(
			'image_1',
			[
			  'label' => __( 'Feature Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Heading', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);	
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);				
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'rufers' ),
			]
		);
		$this->add_control(
        	'company_features', 
			  	[
				'type' => Controls_Manager::REPEATER,
				'seperator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Residential<br> Roofing Services', 'rufers')],
						['block_title' => esc_html__('Commercial<br> Roofing Services', 'rufers')]						
					],
				'fields' => 
				[
					[
						'name' => 'block_icons',
						'label' => esc_html__('Enter The icons', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::SELECT2,
                    	'options'  => get_fontawesome_icons(),
					],
					[
						'name' => 'block_title',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
                    ],
					[
						'name' => 'text',
						'label' => esc_html__('Text', 'rufers'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'features_list',
						'label' => esc_html__('Feature List', 'rufers'),
						'type' => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__('Enter your Feature List', 'rufers')
					],
				],
				'title_field' => '{{block_title}}',
            ]
        );
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
    
    <!--Start About Style3 Area-->          
    <section class="about-style3-area">        
        <div class="container">            
            <div class="row">                
                <?php if($settings['image_1']['id']){ ?>
                <div class="col-xl-6">                    
                    <div class="about-style3__image1">                        
                        <div class="inner">                            
                            <img src="<?php echo esc_url(wp_get_attachment_url($settings['image_1']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers'); ?>">                                
                        </div>
                    </div>
                </div>
                <?php } ?>
                <div class="col-xl-6">                    
                    <div class="about-style3__content">                        
                        <?php if( $settings['subtitle'] || $settings['title']){ ?>                        
                        <div class="sec-title">                            
                            <?php if( $settings['subtitle']){ ?>
                            <div class="sub-title">                                
                                <h6><span class="border-left"></span><?php echo wp_kses($settings['subtitle'], true); ?></h6>                                    
                            </div> 
                            <?php } ?>
                            <?php if($settings['title']){ ?>                               
                            <h2><?php echo wp_kses($settings['title'], true); ?></h2>
                            <?php } ?>                                
                        </div>                            
                        <?php } ?>
                         
                        <div class="inner-content">                            
                            <?php if($settings['text']){ ?>
                            <div class="top-text">                                
                                <p><?php echo wp_kses($settings['text'], true); ?></p>                                        
                            </div>
                            <?php } ?>
                            <div class="row">                                
                                <?php foreach($settings['company_features'] as $key => $item):?>                                 
                                <div class="col-xl-6">                                    
                                    <div class="about-style3__single-box">                                        
                                        <div class="top">                                            
                                            <div class="icon">                                                
                                                <span class="<?php echo esc_attr(str_replace( "icon ",  "", $item['block_icons']));?>"></span>                                                    
                                            </div>                                                
                                            <div class="inner-title">                                                
                                                <h3><?php echo wp_kses($item['block_title'], true) ;?></h3>                                                    
                                            </div>                                                
                                        </div>
                                        <?php if($item['text']){ ?>
                                        <p><?php echo wp_kses($item['text'], true) ;?></p> 
                                        <?php } ?>
                                                                                 
                                        <?php $features_list = $item['features_list'];
                                            if(!empty($features_list)){
                                            $features_list = explode("\n", ($features_list)); 
                                        ?>                                    
                                        <ul>                                            
                                            <?php foreach($features_list as $features): ?>
                                            <li><?php echo wp_kses($features, true); ?></li>
                                            <?php endforeach; ?>
                                        </ul>                                            
                                        <?php } ?>                                            
                                    </div>
                                </div>
                               <?php endforeach;?>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Style3 Area-->
        
    <?php 
	wp_reset_postdata();
	
	}
}
