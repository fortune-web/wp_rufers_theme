<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Company_2 extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_about_company_2';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'About Company 2', 'rufers' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'about_company_2',
			[
				'label' => esc_html__( 'About Company 2', 'rufers' ),
			]
		);	
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Heading', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'rufers' ),
			]
		);	
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'rufers' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text ', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'rufers' ),
			]
		);
		$this->add_control(
			'feature_title',
			[
				'label'       => __( 'Sub Heading', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Sub Heading.', 'rufers' ),
			]
		);
		$this->add_control(
        	'features', 
			[
			'type' => Controls_Manager::REPEATER,
			'separator' => 'before',
			'default' => 
			[
				['block_title' => esc_html__('Certified', 'rufers')],
				['block_title' => esc_html__('Innovative Work', 'rufers')],
				['block_title' => esc_html__('Experienced', 'rufers')],
				
			],
			'fields' => 
				[
					[
						'name' => 'block_icons',
						'label' => esc_html__('Enter The icons', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::SELECT2,
                    	'options'  => get_fontawesome_icons(),
					],
					[
						'name' => 'block_title',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
                    ],
					[
						'name' => 'block_text',
						'label' => esc_html__('Text', 'rufers'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
				],
				'title_field' => '{{block_title}}',
            ]
        );		
		$this->add_control(
			'sig_image',
			[
			  'label' => __( 'Signature Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );		
		$this->add_control(
			'owner_name',
			[
				'label'       => __( 'Author Name ', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Benjamin Everett.', 'rufers' ),
			]
		);
		$this->add_control(
			'designation',
			[
				'label'       => __( 'Author Designation ', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'CEO & Founder', 'rufers' ),
			]
		);
		$this->add_control(
			'bg_transparent_title',
			[
				'label'       => __( 'BG Transparent Title', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Rufers', 'rufers' ),
			]
		);		
		$this->add_control(
			'image_1',
			[
			  'label' => __( 'Feature Image V1', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );		
		$this->add_control(
			'image_2',
			[
			  'label' => __( 'Feature Image V2', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$this->add_control(
			'year',
			[
				'label'       => __( 'Experience Years', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( '09', 'rufers' ),
			]
		);
		$this->add_control(
			'description',
			[
				'label'       => __( 'Experience Description', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Years of Experience', 'rufers' ),
			]
		);
		$this->add_control(
			'icons',
			[
				'label' => esc_html__('Enter The Home icons', 'rufers'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT2,
				'options'  => get_fontawesome_icons(),
			]
		);		
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
    
    <!--Start About Style2 Area-->
    <section class="about-style2-area">    
        <div class="container">        
            <div class="row">
                <div class="col-xl-6">                
                    <div class="about-style2__content">                    
                     	<?php if( $settings['subtitle'] || $settings['title']){ ?>                     
                        <div class="sec-title">                        
                            <?php if( $settings['subtitle']){ ?>
                            <div class="sub-title">                            
                                <h6><span class="border-left"></span><?php echo wp_kses($settings['subtitle'], true); ?></h6>                                
                            </div>
                            <?php } ?>
                            <?php if( $settings['title']){ ?>
                            <h2><?php echo wp_kses($settings['title'], true); ?></h2>
                            <?php } ?>                           
                        </div>                        
                        <?php } ?>
                        <div class="inner-content">                        
                            <?php if($settings['text']){ ?>
                            <div class="text">                            
                                <p><?php echo wp_kses($settings['text'], true); ?></p>                                
                            </div>
                            <?php } ?>                        
                            <?php if($settings['feature_title']){ ?><h5><?php echo wp_kses($settings['feature_title'], true); ?></h5><?php } ?>
                            <ul>                            
                             	<?php foreach($settings['features'] as $key => $item):?>                            
                                <li>                                
                                    <div class="icon">                                    
                                        <span class="<?php echo esc_attr(str_replace("icon ",  "", $item['block_icons']));?>"></span>                                        
                                    </div>                                    
                                    <div class="inner-text">                                    
                                        <h3><?php echo wp_kses($item['block_title'], true) ;?></h3>                                        
                                        <p><?php echo wp_kses($item['block_text'], true) ;?></p>                                        
                                    </div>
                                </li>                                
                                <?php endforeach;?>                                 
                            </ul>                            
                            <div class="authorised-person-info">                            
                            	<?php if($settings['sig_image']['id']) { ?>                            
                                <div class="signature">                                
                                    <img src="<?php echo esc_url(wp_get_attachment_url($settings['sig_image']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers'); ?>">
                                </div>                                
                                <?php } ?>                                
                                <?php if($settings['owner_name']|| $settings['designation']) { ?>                                 
                                <div class="name">                                
                                    <h3><?php echo wp_kses($settings['owner_name'], true); ?></h3>                                    
                                    <span><?php echo wp_kses($settings['designation'], true); ?></span>                                    
                                </div>                                
                                <?php } ?>                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">                
                    <div class="about-style2__image-box">                    
                        <?php if($settings['bg_transparent_title']){ ?><div class="big-title paroller"><?php echo wp_kses($settings['bg_transparent_title'], true); ?></div><?php } ?>
                        <?php if($settings['image_1']['id']) { ?>                        
                        <div class="img-box1 js-tilt">                        
                            <img src="<?php echo esc_url(wp_get_attachment_url($settings['image_1']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers'); ?>">                            
                        </div>                        
                        <?php } ?>                        
                        <div class="img-box2">                        
                         	<?php if($settings['image_2']['id']) { ?>                        
                            <div class="inner">                            
                                <img src="<?php echo esc_url(wp_get_attachment_url($settings['image_2']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers'); ?>">                                
                            </div>                            
                            <?php } ?>                             
                        </div>
                        <?php if($settings['year'] || $settings['description']){  ?>
                        <div class="overlay-box">                        
                            <?php if($settings['year'] ){  ?><h2><?php echo wp_kses( $settings['year'], true );?><span class="flaticon-plus-1"></span></h2><?php } ?>
                            <?php if($settings['description']){  ?><h3><?php echo wp_kses( $settings['description'], true );?></h3><?php } ?>
                        </div>
                        <?php } ?>
						<?php if($settings['icons']){ ?>
                        <div class="icon-box">                        
                            <span class="<?php echo esc_attr(str_replace("icon ",  "", $settings['icons']));?>"></span>                            
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>    
    <!--End About Style2 Area-->
        
    <?php 
	wp_reset_postdata();
	
	}
}
