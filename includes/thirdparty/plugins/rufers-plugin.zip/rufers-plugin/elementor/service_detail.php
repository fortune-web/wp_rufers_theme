<?php

namespace RUFERSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Service_Detail extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rufers_service_detail';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Service Detail', 'rufers' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rufers' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'service_detail',
			[
				'label' => esc_html__( 'Service Detail', 'rufers' ),
			]
		);
		$this->add_control(
			'sidebar_slug',
			[
				'label'   => esc_html__( 'Choose Sidebar', 'rufers' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'Choose Sidebar',
				'options'  => rufers_get_sidebars(),
			]
		);
		$this->add_control(
			'description',
			[
				'label'       => __( 'Description', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your description', 'rufers' ),
			]
		);
		$this->add_control(
			'service_img',
			[
			  'label' => __( 'Service Image', 'rufers' ),
			  'type' => Controls_Manager::MEDIA,
			  'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$this->add_control(
			'description_1',
			[
				'label'       => __( 'Description', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'rufers' ),
			]
		);
		$this->add_control(
            'show_feature_service',
			[
				'label' => __( 'Enable/Disable Feature Services', 'rufers' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enable/Disable Feature Services', 'rufers' ),
			]
		);
		$this->add_control(
        	'our_services', 
				[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
				[
					['block_title' => esc_html__('01. Brownwood', 'rufers')],
					['block_title' => esc_html__('02. Amber', 'rufers')],
				],
				'fields' => 
				[
					[
						'name' => 'service_img2',
						'label' => esc_html__('Feature image', 'rufers'),
						'type' => Controls_Manager::MEDIA,
						'default' => ['url' => Utils::get_placeholder_image_src(),],
					],
					[
						'name' => 'block_title',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'block_text',
						'label' => esc_html__('Text', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
				],
				'title_field' => '{{block_title}}',
			]
        );
		$this->add_control(
            'show_benefits_service',
			[
				'label' => __( 'Enable/Disable Benefits Of Roof', 'rufers' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enable/Disable Benefits Of Roof', 'rufers' ),
			]
		);
		$this->add_control(
			'title_1',
			[
				'label'       => __( 'Title/Heading', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title/Heading', 'rufers' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your text', 'rufers' ),
			]
		);
		$this->add_control(
        	'service_list', 
				[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
				[
					['block_title2' => esc_html__('Cost-Effective', 'rufers')],
					['block_title2' => esc_html__('Fire Protection', 'rufers')],
					['block_title2' => esc_html__('Easy to Repair', 'rufers')]
				],
			'fields' => 
				[
					[
						'name' => 'icons',
						'label' => esc_html__('Enter The icons', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::SELECT2,
						'options'  => get_fontawesome_icons(),
					],
					[
						'name' => 'block_title2',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'block_text2',
						'label' => esc_html__('Text', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
				],
				'title_field' => '{{block_title2}}',
			]
        );
		$this->add_control(
            'show_additional_services',
			[
				'label' => __( 'Enable/Disable Additional Services', 'rufers' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enable/Disable Additional Services', 'rufers' ),
			]
		);
		$this->add_control(
			'title_2',
			[
				'label'       => __( 'Title/Heading', 'rufers' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title/Heading', 'rufers' ),
			]
		);
		$this->add_control(
			'text_1',
			[
				'label'       => __( 'Text', 'rufers' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your text', 'rufers' ),
			]
		);
		$this->add_control(
        	'service', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
				[
					['tab_title' => esc_html__('Roof Repair', 'rufers')],
					['tab_title' => esc_html__('Roof Replacement', 'rufers')],
					['tab_title' => esc_html__('Roof Maintenance', 'rufers')]
				],
			'fields' => 
				[
					[
						'name' => 'icons2',
						'label' => esc_html__('Enter The icons', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::SELECT2,
						'options'  => get_fontawesome_icons(),
					],
					[
						'name' => 'tab_title',
						'label' => esc_html__('Title', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('', 'rufers')
					],
					[
						'name' => 'tab_text',
						'label' => esc_html__('Text', 'rufers'),
						'label_block' => true,
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'rufers')
					],
				],
				'title_field' => '{{tab_title}}',
			]
        );
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
    
    <!--Start Service Details Area-->
    <section class="service-details-area">
        <div class="container">
            <div class="row">
                <?php if (is_active_sidebar( $settings['sidebar_slug'] ) ) : ?>
                <div class="col-xl-4 col-lg-5 order-box-2">
                    <div class="thm-sidebar-box">
                        <?php dynamic_sidebar( $settings['sidebar_slug'] ); ?>
                    </div>
                </div>
                <?php endif; ?>
                <div class="<?php if ( is_active_sidebar( $settings['sidebar_slug'] ) ) echo 'col-xl-8 col-lg-7 order-box-1'; else echo 'col-xl-12 col-lg-12 order-box-1'; ?>">
                    <div class="service-details-content">

                        <div class="top">
                            <?php if($settings['description']){ ?><p><?php echo wp_kses( $settings['description'], true );?></p><?php } ?>
                            <div class="img-box">
                                <img src="<?php echo esc_url(wp_get_attachment_url($settings['service_img']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers');?>">
                            </div>
                        </div>
                        <?php if($settings['description_1']){ ?>
                        <div class="service-details-text-box1">
                            <?php echo wp_kses( $settings['description_1'], true );?>
                        </div>
                        <?php } ?>
                        
                        <?php if($settings['show_feature_service']){ ?>
                        <div class="service-details-text-box2">
                            <div class="row">
                                <?php foreach($settings['our_services'] as $item):?>
                                <!--Start Single Box-->
                                <div class="col-xl-6">
                                    <div class="single-box">
                                        <div class="inner">
                                            <div class="img-box">
                                                <img src="<?php echo esc_url(wp_get_attachment_url($item['service_img2']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'rufers');?>">
                                            </div>
                                            <div class="text-box">
                                                <h3><?php echo wp_kses( $item['block_title'], true );?></h3>
                                                <p><?php echo wp_kses( $item['block_text'], true );?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Single Box-->
                                <?php endforeach;?>
                            </div>
                        </div>
                        <?php } ?>
                        <?php if($settings['show_benefits_service']){ ?>
                        <div class="service-details-text-box3">
                            <?php if($settings['title_1']||$settings['text']){ ?>
                            <div class="top-text">
                                <?php if($settings['title_1']){ ?><h2><?php echo wp_kses( $settings['title_1'], true );?></h2><?php } ?>
                                <?php if($settings['text']){ ?><p><?php echo wp_kses( $settings['text'], true );?></p><?php } ?>
                            </div>
                            <?php } ?>
                            <div class="inner-content">
                                <ul class="clearfix">
                                     <?php foreach($settings['service_list'] as $item):?>
                                    <li class="single-box">
                                        <div class="icon">
                                            <span class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons']), true); ?>"></span>
                                        </div>
                                        <div class="inner">
                                            <h3><?php echo wp_kses( $item['block_title2'], true );?></h3>
                                            <p><?php echo wp_kses( $item['block_text2'], true );?></p>
                                        </div>
                                    </li>
                                    <?php endforeach;?>
                                </ul>
                            </div>
                        </div>
                        <?php } ?>
                        
                        <?php if($settings['show_additional_services']){ ?>
                        <div class="additional-services-box">
                           <?php if($settings['title_2']||$settings['text_1']){ ?>
                            <div class="top-box">
                                 <?php if($settings['title_2']){ ?><h2><?php echo wp_kses( $settings['title_2'], true );?></h2><?php } ?>
                                <?php if($settings['text_1']){ ?><p><?php echo wp_kses( $settings['text_1'], true );?></p><?php } ?>
                            </div>
                            <?php } ?>
                            <div class="inner-content">
                                <ul class="accordion-box">
                                    <?php  $count = 1; foreach($settings['service'] as $item):?>
                                    <li class="accordion block <?php if($count == 1) echo 'active-block'; ?>">
                                        <div class="acc-btn <?php if($count == 1) echo 'active'; ?>">
                                            <div class="icon-outer"><i class="flaticon-down-arrow-2"></i></div>
                                            <h3><i class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons2']), true); ?>"></i> <?php echo wp_kses( $item['tab_title'], true );?></h3>
                                        </div>
                                        <div class="acc-content <?php if($count == 1) echo 'current'; ?>">
                                            <p><?php echo wp_kses( $item['tab_text'], true );?></p>
                                        </div>
                                    </li>
                                    <?php $count++; endforeach;?>
                                </ul>

                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End Service Details Area-->

	<?php
	}
}